# a3.py

# Starter code for assignment 1 in ICS
#  32 Programming with Software Libraries in Python

# Replace the following 
# placeholders with your information.

# Eliya Khajeie 
# ekhajeie@uci.edu
# 85362437

from pathlib import Path
from pathlib import PurePath
import os 
from Profile import Profile
import ui
import re
from ds_client import send

def opt_U(user_path):
    user_U = Profile()
    user_U.load_profile(user_path)
    print(f'Hello {user_U.username} would you like to post anything online Y/N')
    inp_YN = input()
    if inp_YN == "N":
        pass
    if inp_YN == "Y":
        hard_port = 3021
        if user_U.dsuserver == None: #no IP
            print("Great! Now input a server IP, this will be added to your profile!")
            server_IP = input()
            user_U.dsuserver = server_IP
            user_U.save_profile(user_path)
            send(user_U.dsuserver,hard_port,user_U.username,user_U.password,"J") #FIRST INITAL JOIN WITH J AS MESSAGE 
        else:
            print("Great! It seems like you already have a IP address saved!")
            send(user_U.dsuserver,hard_port,user_U.username,user_U.password,"J") #JUST JOIN 
        while True: #coming back 
            print("What would you like to post: -bio or -posts, or Q to quit:")
            print("Remeber! If you want to post both your bio and your posts type -posts, otherwise carry on")
            inpbp = input()
            if inpbp == "-posts":
                post_list = user_U.get_posts()
                if post_list == []:
                    print("You have no posts!, if you would like to create a post use the E function!")
                else:
                    count = 1
                    for i in post_list:
                        print(count, i['entry'])
                        count+=1
                    options = ""
                    for i in range(1, count):
                        options += str(i) + " "
                    print(f'Pick out of the options {options}')
                    user_num_inp = input() 
                    if user_num_inp not in options.split():
                        print("This is not valid")
                        quit()
                    else:
                        user_num_inp = int(user_num_inp)
                        post = post_list[user_num_inp-1]#['entry'] #The exact post #print post to test???
                        post = str(post)
                        dsu = user_U.dsuserver
                        usr = user_U.username
                        pwd = user_U.password
                    inp1 = input("Would you also like to post/change your bio, if say type C -Change bio, P -Post your bio alongside the post, or N -Carry on with just publishing your post\n")
                if inp1 == "C": #CHANGE BIO 
                    new_bio = input("Type your new bio:\n")
                    if len(new_bio) == 0 or new_bio.isspace():
                        print("You cannot have an empty bio try again")
                        quit()
                    else:
                        pass
                    user_U.bio = new_bio
                    user_U.save_profile(user_path) 
                if inp1 in ["C","P"]: #either chnage bio, post both
                    bio = user_U.bio
                    if bio == "" or bio.isspace():
                        print("You cannot have an empty bio try again")
                        quit()
                    else:
                        pass
                    send(dsu,hard_port,usr,pwd,post,bio) #sends to server with bio and msg 
                    print("Great! Your posts and bio is now published")
                if inp1 == "N":
                    send(dsu,hard_port,usr,pwd,post) #sends to server no bio wanted just msg
                    print("Great! Your posts is now published")
            if inpbp == "-bio":
                inp_bio = input("Would you also like to change your bio, C -To change and post your bio. P -Just posts the bio on your profile\n")
                if inp_bio == "P":
                    if user_U.bio == "" or user_U.bio.isspace():
                        print("You cannot have an empty bio try again")
                        quit()
                    else:
                        pass
                    send(user_U.dsuserver,hard_port,user_U.username,user_U.password,"J",user_U.bio) #sends just bio 
                if inp_bio == "C":
                    new_bio = input("Type your new bio:\n")
                    user_U.bio = new_bio
                    if len(new_bio) == 0 or new_bio.isspace():
                        print("You cannot have an empty bio try again")
                        quit()
                    else:
                        pass
                    user_U.save_profile(user_path)
                    send(user_U.dsuserver,hard_port,user_U.username,user_U.password,"J",user_U.bio)
                print("Great! Your bio is now posted")
            if inpbp == "Q":
                quit()



def opt_O(user_path):
    try:
        p = Path("".join(user_path))
        if p.exists() and p.is_file() and p.suffix == ".dsu":
            with open(p,"r") as open_file:
                user_O = Profile()
                user_O.load_profile(user_path)
                print(f'Hello {user_O.username} your file has been loaded!')
                print("Would you like to do any other funtions etc 'E' or 'P' or 'U':")
                inp_from_O = input()
                if inp_from_O == "E":
                    ui.user_optE(user_path)
                if inp_from_O == "P":
                    ui.user_optP(user_path)
                if inp_from_O == "U":
                    opt_U(user_path)
        else:
            print("Your file does not exists, would you like to create it? Y/Q:")
            inp_not_exists = input()
            if inp_not_exists == "Y":
                run()
            if inp_not_exists == "Q":
                quit()
    except FileNotFoundError:
        print("The file you are trying to open does not exist")
        run()
    
def opt_C(user_path, extension_path):
    user_string = ''.join(user_path)
    extension_string = ''.join(extension_path)
    full_path = os.path.join(user_string, extension_string + ".dsu")
    p = Path(full_path)
    if p.exists():
        print("The file you are trying to create already exists, instead I will be opening it")
        opt_O(full_path)
    else:
        print("Please enter your username/password/:(Remeber to use -usr, -pwd, to specify!")
        inp_user_total = input()
        pattern = re.compile(r"-([a-z]+) ([\w-]+)")
        options_total = re.findall(pattern, inp_user_total)
        username = None
        password = None
        for i, val, in options_total:
            if i == "usr":
                inp_user_total = val
                username = val
            elif i == "pwd":
                inp_password = val
                password = val
        
        if username != None and password == None:
            print("Please enter your password")
            inp_password = input()
            password = inp_password
            inp_password = password.replace("-pwd","")
            inp_password = inp_password.replace(" ","")

        if username != None and password != None:
            p.touch()
            User_C = Profile(username=username,password=password)
            User_C.save_profile(full_path)
        print("Please enter a optional bio, if you want to skip just press enter:")
        bio = input()
        if len(bio) > 0 and bio.isspace() == False:
            User_C.bio = bio
            User_C.save_profile(full_path)
        else:
            print("Can't have an empty bio, re run the program and try again!")
            quit()
        print("Would you like to do any other funtions etc 'E' or 'P' or 'U':")
        inp_from_C = input()
        if inp_from_C == "E":
            ui.user_optE(full_path)
        if inp_from_C == "P":
            ui.user_optP(full_path)
        if inp_from_C == "U":
            opt_U(full_path)
        
            

def opt_D(user_path): #good 
    p = Path("".join(user_path))
    if p.exists() and p.is_file() and p.suffix == ".dsu":
        p.unlink()
        print(f'{p} DELETED')
    else:
        ui.user_error()
        run()

def opt_R(user_path): #good
    p = Path("".join(user_path))
    if not p.is_file() or p.suffix != (".dsu"):
        ui.user_error()
    else:
        try:
            with p.open("r") as file:
                lines = file.read()
                if len(lines) == 0:
                    print("EMPTY")
                else:
                    print(lines,end="")
        except FileNotFoundError:
            print("ERROR")

def opt_L(fullpath): #works 
    file_list, directory_list = [], []
    inputp = Path("".join(fullpath))
    if command == "L":
        try:
            for firstpath in inputp.iterdir():
                if firstpath.is_file() == True:
                    file_list.append(firstpath)
                if firstpath.is_file() != True:
                    directory_list.append(firstpath)
            total_list = file_list + directory_list
            if optionind1 not in ["r", "f", "e", "s"] and len(il) >= 4:
                for fil in file_list:
                    print(fil)
                for dir in directory_list:
                    print(dir)
            else:
                try: 
                    if optionind1 == "r":
                        global emp_file
                        emp_file = file_list
                        r(directory_list)
                        if optionind2 == None:
                            for i in emp_file:
                                print(i)
                        if optionind2 is not None:
                            if optionind2 == "f": #option2 should b good 
                                f(emp_file)
                            elif optionind2 == "s": 
                                s(emp_file)
                            elif optionind2 == "e":
                                e(emp_file)

                    elif optionind1 == "f":
                        f(file_list)
                    elif optionind1 == "e":
                        e(total_list)
                    elif optionind1 == "s":
                        s(total_list)
                except (IndexError):
                    pass
        except FileNotFoundError:
            ui.user_error()
            
def r(dl): #works
    if type(dl) == list:
        for i in dl:
            emp_file.append(i)
            r(i)
    else:
        for i in dl.iterdir():
            if i.is_file():
                emp_file.append(i)
            elif i.is_dir():
                emp_file.append(i)
                r(i)

def f(file): #Works 
    for files in file:
        if files.is_file() == True:
            print(files)

def s(file):
    for i in file:
        if PurePath(i).name == extension_se:
            print(i)

def e(file): #needs to find extension    
    for i in file:
        pp = PurePath(i).suffix.replace(".","")
        if pp == extension_se:
            print(i)

def user(): #works
    global optionind1, optionind2
    global command, extension_se, il
    inp = input().replace(" ", "")
    try:
        command = inp[0] 
        #first command of the user 
    except IndexError:
        ui.user_error()
    il = list(inp) 
    #list of user inputs with no spaces #EX L \ics32home -r -s .txt
    optionind1 = None 
    ##--> to keep track of the varialbes 
    optionind2 = None
    optionindex = None
    user_path = None
    extension_se = None
    f_var = False

    for i in range(len(il)):
        if (il[i] == "-" and 
            (il[i+1] == "r" or il[i+1] == "f"
             or il[i+1] == "e" or il[i+1] == "s" 
             or il[i+1] == "n")):
            optionind1 = il[i+1] 
            #letter itself 
            optionindex = i+1 
            #number itself
            user_path = "".join(il[1:optionindex-1])
            f_var = True
            break
    if not f_var:
        user_path = "".join(il[1:]) 
        #if true never hits 
        
    if optionind1 in ["s", "e"]: 
        #checks to see if it is inside s or e 
        extension_se = "".join(il[i+2:]) 
        #joins to a string for extension
    elif optionind1 == "r": #trys for r 
        try:
            if il[optionindex+2] in ["s", "e", "f"]: #trys for option"2"
                optionind2 = il[optionindex+2]
                extension_se = "".join(il[optionindex+3:]) 
                #EX L\ics\home-r-f [to look at]
        except IndexError:
            pass
    try:
        if command == "C" and len(il) > 3:
            extension_path = il[optionindex+1:] 
            #if C gives extension on where to create the file 
            opt_C(user_path,extension_path)
        elif command == "D" and len(il) > 3:
            #no extension runs D
            opt_D(user_path)
        elif command == "R" and len(il) > 3:
             #no extension runs R
            opt_R(user_path)
        elif command == "Q" and len(il) > 3: 
            #quits the problem 
            return False
        elif command == "L" and len(il) > 3: 
            #if it is L runs L function 
            opt_L(user_path)
        elif command == "O" and len(il) > 3:
            opt_O(user_path)
        else:
            if command != "Q":
                ui.user_error()
                 #should be a wrong input 
    except (NameError,IndexError):
        None
    
def run():
    while True:
        if __name__ == "__main__":
            ui.user_options()
            user()
        if command == "Q":
            quit()

run()