# Starter code for assignment 3 in ICS 32 Programming with Software Libraries in Python

# Replace the following placeholders with your information.

# Eliya Khajeie
# ekhajeie@uci.edu
# 85362437

import socket 
import json
from ds_protocol import extract_json
def send(server:str, port:int, username:str, password:str, message:str, bio:str=None):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
            srv.connect((server, port))
            server_msg_join = {"join": {"username": username, "password": password, "token": ""}}
            srv.sendall(json.dumps(server_msg_join).encode('utf-8')) #if join, gives back token 
            s_response = srv.recv(1024).decode('utf-8')

            try:
                extract_response = extract_json(s_response)
                response = extract_response[0]
                server_res_type = extract_response[1] 
                token = response['token']
            except KeyError or TypeError:
                extract_response = extract_json(s_response)
                response = extract_response[0]
                res = response['message']
                print(res)
                return False
            if message == "J" and bio == None: #ONLY JOINING 
                if server_res_type == "ok":
                        return True
                if server_res_type ==  "error":
                        print("Error:" + res)
                        return False 

    
            elif message != "J" and bio == None: #only posting
                my_dict = json.loads(message.replace("'", "\""))
                timestamp = my_dict["timestamp"]
                message = my_dict['entry']
                server_msg_join = {"token":token, "post": {"entry": message,"timestamp": timestamp}}
                srv.sendall(json.dumps(server_msg_join).encode('utf-8')) #if join, gives back token 
                s_response = srv.recv(1024).decode('utf-8')


            elif message != "J" and bio != None:  #posting bio and posts 
                my_dict = json.loads(message.replace("'", "\""))
                message = my_dict['entry']
                timestamp = my_dict["timestamp"]

                server_msg_join = {"token":token, "bio": {"entry": bio ,"timestamp": ""}} #bio
                srv.sendall(json.dumps(server_msg_join).encode('utf-8')) 
                s_response = srv.recv(1024).decode('utf-8')

                server_msg_join = {"token":token, "post": {"entry": message,"timestamp": timestamp}} #post 
                srv.sendall(json.dumps(server_msg_join).encode('utf-8'))  
                s_response = srv.recv(1024).decode('utf-8')

            
            elif message == "J" and bio != None: #only bio
                server_msg_join = {"token":token, "bio": {"entry": bio ,"timestamp": ""}}
                srv.sendall(json.dumps(server_msg_join).encode('utf-8')) #if join, gives back token 
                s_response = srv.recv(1024).decode('utf-8')
            
                 
            else:
                print("Failed to join the server")
                return False
    except socket.error as e:
        print(f"Failed to connect to server: {e}")
        print("Remember, you have to have the right DSU IP in order to connect to the server!")
        return False



